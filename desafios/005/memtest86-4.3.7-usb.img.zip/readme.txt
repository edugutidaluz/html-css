To create a bootable USB drive:
 - Plug in your USB drive.
 - Launch the included ImageUSB application.
 - Select your USB drive from the list.
 - If it is not already selected, select the included image file in step 3.
 - Click 'Write to UFD'.

After accepting a few more prompts this should give you a working
bootable USB drive.

To boot from the drive you may need to go into your BIOS settings and
alter your boot order. Or launch the boot menu at system startup.
The methods for doing this will vary depending on your motherboard.